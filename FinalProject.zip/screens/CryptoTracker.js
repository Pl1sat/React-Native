import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const CryptoTracker = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>CryptoTracker Screen</Text>
            <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Detail')}>
                <Text style={styles.buttonText}>Go to CryptoDetail</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#121212' },
    title: { fontSize: 24, fontWeight: 'bold', color: 'white' },
    button: { marginTop: 20, padding: 10, backgroundColor: 'blue', borderRadius: 5 },
    buttonText: { color: 'white', fontSize: 16 },
});

export default CryptoTracker;
