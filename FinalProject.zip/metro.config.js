const { getDefaultConfig } = require('expo/metro-config');

module.exports = (async () => {
  const defaultConfig = await getDefaultConfig(__dirname);

  return {
    ...defaultConfig,
    transformer: {
      babelTransformerPath: require.resolve('metro-react-native-babel-transformer'),
    },
    resolver: {
      assetExts: [
        'png', 'jpg', 'jpeg', 'svg', 'gif', 'mp4', 'ttf', 'otf', 'json',
      ],
      sourceExts: ['jsx', 'js', 'ts', 'tsx', 'json'],
    },
  };
})();
